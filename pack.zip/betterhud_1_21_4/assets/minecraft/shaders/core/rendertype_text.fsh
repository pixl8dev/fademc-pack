#version 330
#define HEIGHT_BIT 13
#define MAX_BIT 10
#define ADD_OFFSET 4095
#define DEFAULT_OFFSET 10
#define SHADER_VERSION 1
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <fog.glsl>
#endif
#if SHADER_VERSION >= 2
#moj_import <dynamictransforms.glsl>
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;in float cylindricalVertexDistance;
#endif
#else
uniform vec4 ColorModulator;uniform float FogStart;uniform float FogEnd;uniform vec4 FogColor;in float vertexDistance;
#endif
uniform sampler2D Sampler0;in vec4 vertexColor;in vec2 texCoord0;in float applyColor;out vec4 fragColor;void main() {
#ifdef IS_GRAYSCALE
vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
vec4 texColor = texture(Sampler0, texCoord0);
#endif
#ifdef IS_SEE_THROUGH
vec4 color = texColor * vertexColor;
#else
vec4 color = texColor * vertexColor * ColorModulator;
#endif
if (color.a < 0.1) {discard;}
#ifdef IS_SEE_THROUGH
fragColor = color * ColorModulator;
#elif defined(IS_GUI)
fragColor = color;
#elif SHADER_VERSION >= 2
fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#else
fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
#endif
}