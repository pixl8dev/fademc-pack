#version 330

#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#moj_import <minecraft:light.glsl>
#endif
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#moj_import <minecraft:fadecustomcapes/vertex/imports.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

#ifndef NO_OVERLAY
uniform sampler2D Sampler1;
#endif

#ifndef EMISSIVE
uniform sampler2D Sampler2;
#endif

out float sphericalVertexDistance;
out float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
out vec4 vertexPerFaceColorBack;
out vec4 vertexPerFaceColorFront;
#else
out vec4 vertexColor;
#endif

#ifndef EMISSIVE
out vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
out vec4 overlayColor;
#endif

out vec2 texCoord0;

// The unused marker texel has lower alpha only in the owner's texture.
// Keep the camera-relative position smooth so the fragment shader clips at
// the actual distance, rather than dropping one whole triangle at a time.
flat out float capeOwnerView;
out vec3 capeCameraPosition;

// Cape marker colours (texels (0,0) of the cape texture, written by
// ResourcepackBuilder) select how far the mannequin's cape is shifted.
const vec3 DEFAULT_COLOR = vec3(1.0, 0.0, 1.0);
const vec3 SNEAKING_COLOR = vec3(1.0, 1.0, 0.0);
const vec3 SWIMMING_COLOR = vec3(0.0, 1.0, 1.0);
const float COLOR_EPS = 0.05;

// Every Java viewer sees the mannequin riding the owner — these are the drops
// that put the cape back on the shoulders. Crouching/swimming use the REAL
// pose (crouch seat = owner height - 0.6075). Standing is sent as SPIN_ATTACK
// (renders identically, but no 0.6075 vehicle attachment and a 0.6 box) so
// the box sits above the owner's eye: seat = owner height, 0.6075 higher than
// the real standing seat (was 1.23).
const float purple_shift = 1.8375;
const float yellow_shift = 1.0125;
const float turquoise_shift = 0.6;

void main() {
    vec3 localPos = Position;

    // Only cape-shaped (2:1) textures can carry a marker — player skins are
    // square (64x64), so they can never be shifted or hidden by accident.
    bool markerFound = false;
    bool ownerMarker = false;
    float appliedShift = 0.0;
    ivec2 s0 = textureSize(Sampler0, 0);
    if (s0.x >= 64 && s0.x == s0.y * 2) {
        vec4 px = texelFetch(Sampler0, ivec2(0, 0), 0);
        if (px.a > 0.5) {
            vec3 dPurple = abs(px.rgb - DEFAULT_COLOR);
            vec3 dYellow = abs(px.rgb - SNEAKING_COLOR);
            vec3 dTurquoise = abs(px.rgb - SWIMMING_COLOR);
            if (all(lessThan(dPurple, vec3(COLOR_EPS)))) {
                markerFound = true;
                appliedShift = purple_shift;
            } else if (all(lessThan(dYellow, vec3(COLOR_EPS)))) {
                markerFound = true;
                appliedShift = yellow_shift;
            } else if (all(lessThan(dTurquoise, vec3(COLOR_EPS)))) {
                markerFound = true;
                appliedShift = turquoise_shift;
            }
            ownerMarker = markerFound && px.a < 0.9;
        }
    }
    if (markerFound) {
        localPos.y -= appliedShift;
    }
    capeOwnerView = ownerMarker ? 1.0 : 0.0;
    capeCameraPosition = localPos;

    gl_Position = ProjMat * ModelViewMat * vec4(localPos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(localPos);
    cylindricalVertexDistance = fog_cylindrical_distance(localPos);

#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif

#ifndef EMISSIVE
    lightMapColor = sample_lightmap(Sampler2, UV2);
#endif

#ifndef NO_OVERLAY
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    texCoord0 = UV0;

#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif
}
