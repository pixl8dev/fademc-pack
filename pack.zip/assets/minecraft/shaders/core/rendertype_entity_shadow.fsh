#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec3 shadowPos;

out vec4 fragColor;

// The cape mannequin rides the owner, so vanilla would draw a second shadow
// under them. ShadowFeatureRenderer maps u = -x / (2 * radius) + 0.5 (v the
// same on z), so screen-space derivatives recover the caster's radius
// exactly. The mannequin gets minecraft:scale 1.0125 server-side (radius
// 0.5 * 1.0125) — a radius nothing else casts — and only that is dropped.
const float MANNEQUIN_SHADOW_RADIUS = 0.50625;
const float RADIUS_EPS = 0.001;

void main() {
    float worldStep = length(vec2(dFdx(shadowPos.x), dFdy(shadowPos.x)))
            + length(vec2(dFdx(shadowPos.z), dFdy(shadowPos.z)));
    float uvStep = length(vec2(dFdx(texCoord0.x), dFdy(texCoord0.x)))
            + length(vec2(dFdx(texCoord0.y), dFdy(texCoord0.y)));
    if (uvStep > 0.0) {
        float radius = worldStep / (2.0 * uvStep);
        if (abs(radius - MANNEQUIN_SHADOW_RADIUS) < RADIUS_EPS) {
            discard;
        }
    }

    vec4 color = texture(Sampler0, clamp(texCoord0, 0.0, 1.0));
    color *= vertexColor * ColorModulator;
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
